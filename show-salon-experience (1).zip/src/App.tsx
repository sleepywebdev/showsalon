import HomePage from "./routes/index";

export default function App() {
  return <HomePage />;
}
